#include<stdio.h>

int newEdge,i,j,min,u,v,cost[100][100],n,a,b,parent[100],mincost=0;
void kruskal()
{
    printf("\n The minimum edges are as follows : \n ");
            newEdge=1;
            while(newEdge<n)
            {
                        for(i=1,min=999;i<=n;i++)
                                    for(j=1;j<=n;j++)
                                    {
                                                if(cost[i][j]<min)
                                                {
                                                            min=cost[i][j];
                                                            a=u=i;
                                                            b=v=j;
                                                }
                                    }
                        while(parent[u])
                                    u=parent[u];
                        while(parent[v])
                                    v=parent[v];
                        if(u!=v)
                        {
                                    printf("\n Edge %d : (%d, %d) = %d \n",newEdge,a,b,min);
                                    newEdge++;
                                    mincost+=min;
                                    parent[v]=u;
                        }
                        cost[a][b]=cost[b][a]=999;
            }
}
int main()
{
            printf(" Enter the number of nodes: ");
            scanf("%d",&n);

            printf("\n Enter the weighted matrix below: \n");
            printf("\n NOTE: Enter 999 for infinity to indicate no edge \n");
            for(i=1;i<=n;i++)
                        for(j=1;j<=n;j++)
                                    scanf("%d",&cost[i][j]);

            kruskal();
            return 0;
}
